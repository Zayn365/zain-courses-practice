import './App.css';
import MyContext from './Context';
import HelperFunc from './hooks/HelperFunc';
import Todo from './components/Todo';
import Toggle from './hooks/Toggle';

function App() {
 const [todo , handleTodo , list , handleSubmit , id , handleId , update , handleUpdate , submitUpdate , handleRemove] = HelperFunc();
 const [toggle , handleToggle] = Toggle(false);
  return (
    <div className="App">
      <MyContext.Provider 
        value={{todo , handleTodo , list , handleSubmit , id , handleId , update , handleUpdate , submitUpdate , handleRemove , toggle , handleToggle}}>
      <Todo />
      </MyContext.Provider>
    </div>
  );
}

export default App;
