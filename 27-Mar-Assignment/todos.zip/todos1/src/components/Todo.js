import React , {useContext} from 'react'
import MyContext from '../Context'
import Input from './Input';


const Todo = () => {
    
    const x = useContext(MyContext);
    // console.log(x);
  return (
    <div>
      {!x.toggle ?
       <Input
       type="text"
       placeholder="Add ME"
       onChange={x.handleTodo}
       value={x.todo}
       onClick={x.handleSubmit}
       Name="ADD"
       />
       : 
       <Input
       type="text"
       onChange={x.handleUpdate}
       value={x.update}
       onClick={x.submitUpdate}
       toggle = {x.toggle}
       handleToggle = {x.handleToggle}
       id = {x.id}
       Name="UPDATE"
       />
       }
        <br />
        <h1>TODOS:</h1>
        {x.list.map((val , key) => {
            // console.log(val.id)
            return <>
              <p key={'Hello MANO' + key}>{val.id}.{val.task}</p>
              <br />
              <p>
                <button onClick={() => {x.handleToggle(); x.handleId(val.id)}}>Update</button>
                <button onClick={() => {x.handleRemove(val.id); x.handleId(val.id)}}>Remove</button>
              </p>
            </>
        })}
    </div>
  )
}

export default Todo