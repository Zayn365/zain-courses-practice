import {useState} from 'react';


function Toggle(intVal) {
   const [toggle , setToggle] = useState(intVal);


   const handleToggle = () => {
    setToggle(!toggle);
   } 

   return [toggle , handleToggle] 
}

export default Toggle;