import React from 'react'

const Input = props => {
  return (
    <div>
      <form> 
      <h1>{props.Name} TODO</h1>   
      <input
      type={props.type}
      placeholder={props.placeholder}
      value={props.value}
      onChange={(e) => props.onChange(e)}
      />
      {!props.toggle ?  
      <button onClick={(e) => { props.onClick();}} >{props.Name}</button> :  
      <button onClick={(e) => { e.preventDefault(); props.onClick(props.id); props.handleToggle()}} >
        {props.Name}
      </button>}
     
      </form>
    </div>
  )
}

export default Input