import { useEffect, useState } from 'react';
import axios from 'axios';

const HelperFunc = () => {
  const [todo, setTodo] = useState('');
  const [list, setList] = useState([]);
  const [id, setId] = useState();
  const [update, setUpdate] = useState('');

  useEffect(() => {
    async function fetchData() {
      const res = await axios.get('http://localhost:5000/');
      const data = res.data;
      setList(data);
    }
    fetchData();
  }, []);

  async function postData() {
    await axios.post('http://localhost:5000/', {
      id: list.length + 1,
      task: todo,
    });
  }

  async function updateData() {
    await axios.put(`http://localhost:5000/${id}`, {
      task: update,
    });
  }

 useEffect(() => {
  async function deleteData() {
  await axios.delete(`http://localhost:5000/${id}`);
}
// console.log(`http://localhost:5000/${id}`);
 deleteData();
})



  function handleTodo(e) {
    setTodo(e.target.value);
  }

  async function handleSubmit() {
    await postData();
    const newItem = { id: list.length + 1, task: todo };
    setList([...list, newItem]);
    setTodo('');
  }

  function handleId(id) {
    setId(id);
  }

  function handleUpdate(e) {
    setUpdate(e.target.value);
  }

  async function submitUpdate(id) {
    const updatedList = list.map(val => {
      if (val._id === id) {
        return { ...val, task: update };
      } else {
        return val;
      }
    });
    await updateData();
    setList(updatedList);
    setUpdate('');
  }

  function handleRemove(id) {
    const updatedList = list.filter(val => val.id !== id);
    setList(updatedList);
    // deleteData(id);

  }

  return [    todo,    handleTodo,    list,    handleSubmit,    id,    handleId,    update,    handleUpdate,    submitUpdate,    handleRemove,  ];
};

export default HelperFunc;
